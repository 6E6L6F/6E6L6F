import json
import os
import logging
from telethon import TelegramClient, events, Button
from telethon.tl.types import ChatAdminRights
from telethon.tl.functions.channels import EditAdminRequest
from config import Config
import httpx

for folder in ["logs", "sessions", "data", "hashs"]:
    if not os.path.exists(folder):
        os.makedirs(folder)

logging.basicConfig(
    filename="logs/bot.log",
    filemode="a",
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO
)

client = TelegramClient('bot_session', Config.API_ID, Config.API_HASH).start(bot_token=Config.TOKEN)

button_tools = [
    [Button.inline('بلاک کردن کاربر', b'blocker_tool')],
    [Button.inline('ریپورتر', b'reporter_tool')],
    [Button.inline('اسپمر', b'spmmaer_tool')],
    [Button.inline('ریمور', b'remover_tool')],
    [Button.inline('جوینر', b'joiner_tool')],
    [Button.inline('افزودن سطح دسترسی', b'add_permission')]
]
button_start = [
    [Button.inline('افزودن زامبی', b'add_zombie')],
    [Button.inline('ابزار ها', b'tools')],
    [Button.inline('آمار اکانت ها', b'accounts')],
    [Button.inline('حذف اکانت', b'del_accounts')],
    [Button.inline('دریافت لاگ ها', b'get_logs')]

]

@client.on(events.NewMessage(pattern='/start'))
async def start(event):
    await event.respond('لطفا یکی از دکمه‌ها را انتخاب کنید:', buttons=button_start)
    logging.info(f"کاربر {event.sender_id} فرمان /start را اجرا کرد.")

@client.on(events.CallbackQuery)
async def callback(event):
    data = event.data.decode('utf-8')
    logging.info(f"کاربر {event.sender_id} دکمه '{data}' را انتخاب کرد.")
    if data == "tools":
        await event.respond("به بخش ابزار ها خوش آمدید",buttons=button_tools)
    
    elif data == "accounts":
        try:
            with open("data/accounts.json", "r", encoding="utf-8") as json_file:
                accounts_data = json.load(json_file)
            messages = []
            message = ""
            for index, account in enumerate(accounts_data):
                account_info = f"اکانت {index + 1}:\nID: {account.get('id')}\nUsername: {account.get('username')}\nPhone: {account.get('phone')}\n\n"                
                if len(message + account_info) > 4096:  
                    messages.append(message)
                    message = ""
                message += account_info
            
            if message:
                messages.append(message)
            
            for msg in messages:
                await event.respond(msg)
            
            logging.info(f"اطلاعات اکانت‌ها برای کاربر {event.sender_id} ارسال شد.")
        
        except FileNotFoundError:
            await event.respond("فایل accounts.json پیدا نشد.")
            logging.error("فایل accounts.json پیدا نشد.")
    
    elif data == "del_accounts":
        await event.respond("account deleted")
    
    elif data == "get_logs":
        await event.respond("logs")
    
    else:        
        async with client.conversation(event.sender_id) as conv:
            if data == 'add_zombie':
                await event.respond('شماره تلفن اکانت را وارد کنید:')
                phone = (await conv.get_response()).message
                
                async with httpx.AsyncClient() as http_client:
                    response = await http_client.post(f"{Config.FASTAPI_BASE_URL}/send_code/", json={"phone": phone})

                logging.info(f"کاربر {event.sender_id} شماره تلفن {phone} را وارد کرد.")

                await event.respond('کد ورود ارسال شده را وارد کنید:')
                code = (await conv.get_response()).message
                try:
                    with open(f"hashs/{phone}_phone.txt", "r") as f:
                        hash_code = f.read().strip()
                except FileNotFoundError:
                    await event.respond("کد hash پیدا نشد. دوباره تلاش کنید.")
                    return
                
                async with httpx.AsyncClient() as http_client:
                    response = await http_client.post(
                        f"{Config.FASTAPI_BASE_URL}/login/",
                        json={"phone": phone, "code": code, "hash_code": hash_code}
                    )

                logging.info(f"کاربر {event.sender_id} کد ورود را وارد کرد.")
                if response.status_code == 200:
                    await event.respond('اکانت اضافه شد.')
                    logging.info(f"اکانت کاربر {phone} اضافه شد.")
                
                else:
                    await event.respond("ورود ناموفق بود. لطفاً دوباره تلاش کنید.")
                    logging.info(f"مشکلی رخ داده است : {response.status_code} \n {response.text}")
                
            else:        
                await event.respond('آیدی تارگت را وارد کنید:')
                target = (await conv.get_response()).message
                logging.info(f"آیدی تارگت توسط کاربر {event.sender_id} وارد شد: {target}")

                if data == 'blocker_tool':
                    async with httpx.AsyncClient() as http_client:
                        response = await http_client.post(
                            f"{Config.FASTAPI_BASE_URL}/block_user/",
                            json={
                                "user_id": target
                                }
                        )
                    await event.respond('کاربر بلاک شد.')                
                    logging.info(f"کاربر {target} توسط {event.sender_id} بلاک شد.")

                elif data == 'reporter_tool':
                    await event.respond('''
                                        \rتایپ ریپورت را انتخاب کنید
                                        \n
                                        \r1: Spam
                                        \r2: Violence
                                        \r3: Pornography
                                        \r4: ChildAbuse
                                        \r5: Other                                     
                                        \r عدد وارد کنید
                                        '''
                                    )
                    
                    report_type = (await conv.get_response()).message
                    await event.respond(f'تایپ ریپورت انتخاب شد {report_type}\n متن ریپورت را ارسال نمایید.')
                    
                    report_text = (await conv.get_response()).message
                    async with httpx.AsyncClient() as http_client:
                        response = await http_client.post(
                            f"{Config.FASTAPI_BASE_URL}/report_user/",
                            json={
                                "user_id": target ,
                                "report_type_key":report_type ,
                                "report_text":report_text
                            }
                        )
                    await event.respond('ریپورت انجام شد.')
                    logging.info(f"ریپورت توسط کاربر {event.sender_id} برای {target} انجام شد.")

                elif data == 'spmmaer_tool':
                    await event.respond('متن اسپم را میخواهید ست کنید؟ (بله/خیر):')
                    response = (await conv.get_response()).message
                    if response.lower() == 'بله':
                        await event.respond('متن اسپم را ارسال کنید:')
                        message_text = (await conv.get_response()).message
                        logging.info(f"کاربر {event.sender_id} متن اسپم را تنظیم کرد: {message_text}")
                    else:
                        message_text = "None"
                        
                    await event.respond('تعداد اسپم را وارد کنید (مثال: 100)')
                    message_count = (await conv.get_response()).message
                    
                    logging.info(f"کاربر {event.sender_id} تعداد اسپم را {message_count} تنظیم کرد")

                    await event.respond('ثانیه ارسال اسپم را ارسال کنید (مثال: 1)')
                    delay = (await conv.get_response()).message
                    
                    logging.info(f"کاربر {event.sender_id} ثانیه ارسال اسپم را {delay} ثانیه تنظیم کرد")
    
                    async with httpx.AsyncClient() as http_client:
                        response = await http_client.post(
                            f"{Config.FASTAPI_BASE_URL}/send_spam/",
                            json={
                                "user_id": target ,
                                "message_count":message_count ,
                                "message_text":message_text,
                                "delay":delay
                            }
                        )    
                    await event.respond('اسپم انجام شد.')
                    logging.info(f"اسپم برای کاربر {target} توسط {event.sender_id} انجام شد.")

                elif data == 'remover_tool':
                    
                    async with httpx.AsyncClient() as http_client:
                        response = await http_client.post(
                            f"{Config.FASTAPI_BASE_URL}/remover_member/",
                            json={
                                "channel_id": target ,
                            }
                        )
                    
                    await event.respond('ریمور در حال اجراست...')
                    logging.info(f"ریمور توسط کاربر {event.sender_id} اجرا شد.")

                elif data == 'joiner_tool':
                    async with httpx.AsyncClient() as http_client:
                        response = await http_client.post(
                            f"{Config.FASTAPI_BASE_URL}/join_channel/",
                            json={
                                "channel_id": target ,
                            }
                        )

                    await event.respond('اکانت‌ها جوین شدند!')
                    logging.info(f"اکانت‌ها به گروه توسط کاربر {event.sender_id} جوین شدند.")

                elif data == 'add_permission':
                    await event.respond('لینک یا آیدی گروه را وارد کنید:')
                    group_link_or_id = (await conv.get_response()).message

                    try:
                        with open(Config.ACCOUNT_DATA, "r", encoding="utf-8") as json_file:
                            accounts_list = json.load(json_file)
                        logging.info(f"فایل اکانت‌ها بارگذاری شد.")
                    except FileNotFoundError:
                        await event.respond("فایل اطلاعات اکانت‌ها پیدا نشد.")
                        logging.error("فایل اطلاعات اکانت‌ها پیدا نشد.")
                        return

                    admin_rights = ChatAdminRights(
                        change_info=True,
                        delete_messages=True,
                        ban_users=True,
                        invite_users=True,
                        pin_messages=True,
                        add_admins=True,
                        manage_call=True,
                    )

                    for account in accounts_list:
                        user_id = account.get("id")
                        if not user_id:
                            continue

                        try:
                            await client(EditAdminRequest(
                                group_link_or_id,
                                user_id,
                                admin_rights,
                                rank="Full Admin"
                            ))
                            logging.info(f"کاربر {user_id} به عنوان ادمین اضافه شد.")
                        except Exception as e:
                            logging.error(f"خطا در افزودن ادمین برای کاربر {user_id}: {e}")
                    await event.respond(f"تمامی اکانت ها ادمین شدند")

client.run_until_disconnected()
