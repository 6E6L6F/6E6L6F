import logging
import os
import json
import random
import asyncio

from config import Config
from pydantic import BaseModel
from fastapi import (
    FastAPI,
    HTTPException,
    BackgroundTasks
)

from telethon import (
    TelegramClient,
    functions,
    types
)

from telethon.errors import (
    SessionPasswordNeededError,
    UserPrivacyRestrictedError,
    FloodWaitError,
    ChatAdminRequiredError
)
from telethon.tl.functions.contacts import BlockRequest
from telethon.tl.functions.channels import JoinChannelRequest

logging.basicConfig(
    filename="logs/app.log",
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

app = FastAPI()

class RemoveRequest(BaseModel):
    channel_id: str
    
class PhoneRequest(BaseModel):
    phone: str

class UserIDRequest(BaseModel):
    user_id: int

class ChannelRequest(BaseModel):
    channel_id: str

class ReportRequest(BaseModel):
    user_id: int
    report_type_key: int = 1
    report_text: str = ""

class LoginRequest(BaseModel):
    phone: str
    code: str
    hash_code: str
    password: str = None
    
class MessageRequest(BaseModel):
    user_id: str
    message_count: int
    message_text: str = None
    delay: float = 1.0
    
async def remove_members(client, channel_id):
    removed_count = 0
    admin_ids = []
    try:
        async for user in client.iter_participants(channel_id):
            try:
                await client.kick_participant(channel_id, user)
                removed_count += 1
                logging.info(f"Removed user {user.id} from {channel_id}")
            except ChatAdminRequiredError:
                admin_ids.append(user.id)  
                logging.warning(f"Cannot remove {user.id} due to admin restrictions.")
                continue
    except Exception as e:
        logging.error(f"Error in removing members: {e}")
    return removed_count, admin_ids

async def remove_channel_members_background(channel_id):
    session_files = [f for f in os.listdir(Config.SESSIONS_FOLDER) if f.endswith('.session')]
    removal_data = []

    if not session_files:
        logging.warning("No session files found.")
        return

    for session_file in session_files:
        client = TelegramClient(os.path.join(Config.SESSIONS_FOLDER, session_file), Config.API_ID, Config.API_HASH, proxy=Config.PROXY)
        await client.start()
        removed_count, admin_ids = await remove_members(client, channel_id)
        await client.disconnect()

        removal_data.append({
            "channel_id": channel_id,
            "admin_ids": admin_ids,  
            "removed_count": removed_count
        })

    json_file_path = os.path.join("data", "removal_data.json")
    with open(json_file_path, "w") as json_file:
        json.dump(removal_data, json_file, ensure_ascii=False, indent=4)
    
    logging.info(f"Completed removal for channel {channel_id}")
    
async def report_user(user_id, report_type_key=1, report_text=""):
    report_type = Config.REPORT_TYPES.get(report_type_key, types.InputReportReasonSpam)
    session_files = [f for f in os.listdir(Config.SESSIONS_FOLDER) if f.endswith('.session')]

    for session_file in session_files:
        session_path = os.path.join(Config.SESSIONS_FOLDER, session_file)
        client = TelegramClient(session_path, Config.API_ID, Config.API_HASH, proxy=Config.PROXY)

        async def report():
            await client.connect()
            if not await client.is_user_authorized():
                logger.warning(f"سشن {session_file} معتبر نیست.")
                await client.disconnect()
                return

            try:
                await client(functions.account.ReportPeerRequest(
                    peer=types.InputPeerUser(user_id=user_id, access_hash=0),
                    reason=report_type(),
                    message=report_text
                ))
                logger.info(f"کاربر {user_id} توسط {session_file} ریپورت شد.")
            except UserPrivacyRestrictedError:
                logger.warning(f"عدم امکان ریپورت برای کاربر {user_id} توسط {session_file} به دلیل محدودیت‌های حریم خصوصی.")
            except Exception as e:
                logger.error(f"خطا در ریپورت کاربر {user_id} توسط {session_file}: {e}")
            finally:
                await client.disconnect()

        await report()

async def join_channel(client, target_channel):
    try:
        await client(JoinChannelRequest(target_channel))
        logger.info(f"با موفقیت به کانال {target_channel} پیوست با سشن {client.session.filename}.")
    except Exception as e:
        logger.error(f"خطا در پیوستن به کانال {target_channel} با سشن {client.session.filename}: {e}")

async def join_channel_with_sessions(target_channel: str):
    session_files = [f for f in os.listdir(Config.SESSIONS_FOLDER) if f.endswith('.session')]

    if not session_files:
        logger.warning("هیچ فایل سشنی در پوشه sessions یافت نشد.")
        raise HTTPException(status_code=404, detail="هیچ فایل سشنی موجود نیست.")

    for session_file in session_files:
        session_path = os.path.join(Config.SESSIONS_FOLDER, session_file)
        client = TelegramClient(session_path, api_id=Config.API_ID, api_hash=Config.API_HASH, proxy=Config.PROXY)
        await client.start()
        await join_channel(client, target_channel)
        await client.disconnect()
        logger.info(f"اتصال سشن {session_file} قطع شد.")

async def block_user(client, user_id):
    try:
        await client(BlockRequest(id=user_id))
        logger.info(f"کاربر {user_id} توسط سشن {client.session.filename} بلاک شد.")
    except Exception as e:
        logger.error(f"خطا در بلاک‌کردن کاربر {user_id} با سشن {client.session.filename}: {e}")

async def block_user_with_sessions(user_id: int):
    session_files = [f for f in os.listdir(Config.SESSIONS_FOLDER) if f.endswith('.session')]

    if not session_files:
        logger.warning("هیچ فایل سشنی در پوشه sessions یافت نشد.")
        raise HTTPException(status_code=404, detail="هیچ فایل سشنی موجود نیست.")

    for session_file in session_files:
        session_path = os.path.join(Config.SESSIONS_FOLDER, session_file)
        client = TelegramClient(session_path, api_id=Config.API_ID, api_hash=Config.API_HASH, proxy=Config.PROXY)
        await client.start()
        await block_user(client, user_id)
        await client.disconnect()
        logger.info(f"اتصال سشن {session_file} قطع شد.")

async def send_code(phone: str):
    client = TelegramClient(f"sessions/{phone}.session", Config.API_ID, Config.API_HASH, proxy=Config.PROXY)
    await client.connect()
    sent_code = await client.send_code_request(phone)
    await client.disconnect()

    with open(f"hashs/{phone}_phone.txt", "w") as f:
        f.write(sent_code.phone_code_hash)

    logger.info(f"Verification code sent to {phone}")

async def send_messages(client, target, message, count, delay):
    for i in range(count):
        try:
            text = message if message else random.choice(Config.DEFAULT_MESSAGES)
            await client.send_message(target, text)
            logger.info(f"پیام '{text}' به {target} ارسال شد ({i+1}/{count})")
            await asyncio.sleep(delay)
        except FloodWaitError as e:
            logger.warning(f"خطای محدودیت سرعت (FloodWait) رخ داد. زمان انتظار: {e.seconds} ثانیه.")
            await asyncio.sleep(e.seconds)
        except Exception as e:
            logger.error(f"خطا در ارسال پیام به {target}: {e}")
            
async def spam_messages(target_id, message_count, message_text, delay):
    session_files = [f for f in os.listdir(Config.SESSIONS_FOLDER) if f.endswith('.session')]

    if not session_files:
        logger.warning("هیچ فایل سشنی در پوشه sessions یافت نشد.")
        return

    for session_file in session_files:
        session_path = os.path.join(Config.SESSIONS_FOLDER, session_file)
        client = TelegramClient(session_path, Config.API_ID, Config.API_HASH, proxy=Config.PROXY)
        await client.start()

        try:
            target_entity = await client.get_input_entity(target_id)
            await send_messages(client, target_entity, message_text, message_count, delay)
        except Exception as e:
            logger.error(f"خطا در پردازش هدف {target_id} با سشن {session_file}: {e}")
        
        await client.disconnect()
        logger.info(f"اتصال سشن {session_file} قطع شد.")


@app.post("/remover_member/")
async def report_user_endpoint(data: RemoveRequest, background_tasks: BackgroundTasks):
    logger.info(f"درخواست ریموور برای چنل: {data.channel_id}")
    background_tasks.add_task(remove_channel_members_background, data.channel_id)
    return {"message": f"درخواست ریموور کاربر {data.user_id} در حال پردازش است."}
              
@app.post("/send_spam/")
async def send_messages_endpoint(data: MessageRequest, background_tasks: BackgroundTasks):
    logger.info(f"درخواست ارسال پیام به {data.user_id}")
    text = data.message_text if data.message_text != "None" else None
    background_tasks.add_task(spam_messages, data.user_id, data.message_count, text, data.delay)
    return {"message": f"درخواست ارسال پیام به {data.user_id} در حال پردازش است."}

@app.post("/report_user/")
async def report_user_endpoint(data: ReportRequest, background_tasks: BackgroundTasks):
    logger.info(f"درخواست ریپورت کاربر: {data.user_id}")
    background_tasks.add_task(report_user, data.user_id, data.report_type_key, data.report_text)
    return {"message": f"درخواست ریپورت کاربر {data.user_id} در حال پردازش است."}

@app.post("/join_channel/")
async def join_channel_endpoint(data: ChannelRequest, background_tasks: BackgroundTasks):
    logger.info(f"درخواست پیوستن به کانال: {data.channel_id}")
    background_tasks.add_task(join_channel_with_sessions, data.channel_id)
    return {"message": f"درخواست پیوستن به کانال {data.channel_id} در حال پردازش است."}

@app.post("/block_user/")
async def block_user_endpoint(data: UserIDRequest, background_tasks: BackgroundTasks):
    logger.info(f"درخواست بلاک برای کاربر: {data.user_id}")
    background_tasks.add_task(block_user_with_sessions, data.user_id)
    return {"message": f"درخواست بلاک برای کاربر {data.user_id} در حال پردازش است."}

@app.post("/send_code/")
async def request_code_endpoint(data: PhoneRequest, background_tasks: BackgroundTasks):
    logger.info(f"Received code request for phone: {data.phone}")
    background_tasks.add_task(send_code, data.phone)
    return {"message": "کد تأیید ارسال شد."}

@app.post("/login/")
async def login_endpoint(data: LoginRequest):
    client = TelegramClient(f"sessions/{data.phone}.session", Config.API_ID, Config.API_HASH, proxy=Config.PROXY)
    await client.connect()

    try:
        with open(f"hashs/{data.phone}_phone.txt", "r") as f:
            stored_hash = f.read().strip()
    except FileNotFoundError:
        logger.error(f"Hash code not found for phone: {data.phone}")
        raise HTTPException(status_code=404, detail="hash_code پیدا نشد.")

    try:
        await client.sign_in(data.phone, data.code, phone_code_hash=stored_hash)
    except SessionPasswordNeededError:
        if data.password:
            await client.sign_in(password=data.password)
        else:
            logger.warning(f"Two-step verification required for phone: {data.phone}")
            raise HTTPException(status_code=401, detail="رمز دومرحله‌ای نیاز است.")

    if await client.is_user_authorized():
        user_info = await client.get_me()
        new_account_data = {
            "id": user_info.id,
            "username": user_info.username,
            "phone": data.phone,
            "first_name": user_info.first_name,
            "last_name": user_info.last_name,
            "is_bot": user_info.bot
        }

        if os.path.exists():
            with open(Config.ACCOUNT_DATA, "r", encoding="utf-8") as json_file:
                accounts_list = json.load(json_file)
        else:
            accounts_list = []

        accounts_list.append(new_account_data)

        with open(Config.ACCOUNT_DATA, "w", encoding="utf-8") as json_file:
            json.dump(accounts_list, json_file, ensure_ascii=False, indent=4)

        logger.info(f"Login successful for phone: {data.phone}")
        await client.disconnect()
        return {"message": "ورود موفقیت‌آمیز بود! سشن و اطلاعات اکانت ذخیره شد."}
    else:
        logger.error(f"Login failed for phone: {data.phone}")
        raise HTTPException(status_code=401, detail="ورود ناموفق بود.")

if __name__ == "__main__":
    import uvicorn
    logger.info("Starting FastAPI server...")
    uvicorn.run(app, host="0.0.0.0", port=8000)
