from telethon import types

class Config:
    API_ID = '21712330'
    API_HASH = '99c69c561bd4d45393efbff8db681c18'
    TOKEN = '6523551442:AAGhJT1lGcOQ5ePSpEcJozyDcbfT5yl0t3E'

    SESSIONS_FOLDER = "../sessions/"
    DEFAULT_MESSAGES = [
        "سلام!",
        "چطوری؟",
        "امیدوارم روز خوبی داشته باشی!",
        "این یک پیام تست است.",
        "پیام نمونه ارسال شد."
    ]
    
    PROXY = (
        "socks5", "127.0.0.1", 9050
        )
    
    REPORT_TYPES = {
        1: types.InputReportReasonSpam,
        2: types.InputReportReasonViolence,
        3: types.InputReportReasonPornography,
        4: types.InputReportReasonChildAbuse,
        5: types.InputReportReasonOther
    }
    ACCOUNT_DATA = "data/accounts.json"

